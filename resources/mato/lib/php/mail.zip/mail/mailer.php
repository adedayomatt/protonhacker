<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-6.0.5/src/Exception.php';
require 'PHPMailer-6.0.5/src/PHPMailer.php';
require 'PHPMailer-6.0.5/src/SMTP.php';


class EMAIL{
	private $mailer;
	
	private $client;
	private $subject;
	private $body;
	
	
	function __construct($client,$subject,$body){
		$this->client = $client;
		$this->subject = $subject;
		$this->body = $body;
		
		//Set up the SMTP
		$this->mailer = new PHPMailer;
        $this->mailer->isSMTP();
        $this->mailer->SMTPSecure = "ssl"; 
        $this->mailer->Host = 'cpanel-box5659.bluehost.com';
        $this->mailer->Port = 465;
        $this->mailer->CharSet = 'utf-8';
        $this->mailer->SMTPAuth = true;
	}
	
	public function sendHackersCopy(){//Hacker's copy of mail
		$mail = $this->mailer; //get the mailer object
		
        $mail->Username = 'request@protonhacker.com';
        $mail->Password = 'HackTheFuck';
        $mail->setFrom('request@protonhacker.com', 'Hacking Request');
        $mail->addAddress('hacker@protonhacker');
        $mail->addReplyTo($this->client);
        $mail->Subject = $this->subject;
        $mail->Body = $this->body;
		
		 if (!$mail->send()){
            return '';
        } else {
            return $mail->ErrorInfo;
        }
	}		

	public function sendClientCopy(){
		$mail = $this->mailer; //get the mailer object
		
		 $mail->Username = 'request@protonhacker.com';
        $mail->Password = 'HackTheFuck';

       // $mail->Username = 'hacker@protonhacker.com';
        //$mail->Password = '';
        $mail->setFrom('hacker@protonhacker.com', 'ProtonHacker Team');
        $mail->addAddress($this->client);
        $mail->addReplyTo('hacker@protonhacker.com', 'ProtonHacker Team');
        $mail->Subject = $this->subject;
        $mail->Body = $this->body;
		 if (!$mail->send()){
            return $mail->ErrorInfo;
        } else {
			return true;
        }
	}		
}

$m = new EMAIL($recipient = 'adedayomatt@gmail.com','Subject','The body');
$send = $m->sendClientCopy();
if($send == true){
	echo "email sent to $recipient !";
}
else{
	echo $send;
}
 ?>
